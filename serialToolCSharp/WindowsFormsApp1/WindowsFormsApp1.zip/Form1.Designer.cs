﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.txtFile = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.cbbbaut = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lbltmp = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.txtimuID = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txtShowData = new System.Windows.Forms.TextBox();
            this.btncali = new System.Windows.Forms.Button();
            this.lblyaw = new System.Windows.Forms.Label();
            this.lblpitch = new System.Windows.Forms.Label();
            this.lblroll = new System.Windows.Forms.Label();
            this.lblwz = new System.Windows.Forms.Label();
            this.lblwy = new System.Windows.Forms.Label();
            this.lblwx = new System.Windows.Forms.Label();
            this.lbltime = new System.Windows.Forms.Label();
            this.tblpf = new System.Windows.Forms.TrackBar();
            this.cbbmhz = new System.Windows.Forms.ComboBox();
            this.cbbBaudRate = new System.Windows.Forms.ComboBox();
            this.cbbComList = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbllpf = new System.Windows.Forms.Label();
            this.lblmhz = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSend = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnflashRead = new System.Windows.Forms.Button();
            this.btnflashWrite = new System.Windows.Forms.Button();
            this.btnSetParam = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.ComDevice = new System.IO.Ports.SerialPort(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblpf)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1364, 593);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.txtFile);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.cbbbaut);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.lbltmp);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.txtimuID);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.txtShowData);
            this.tabPage1.Controls.Add(this.btncali);
            this.tabPage1.Controls.Add(this.lblyaw);
            this.tabPage1.Controls.Add(this.lblpitch);
            this.tabPage1.Controls.Add(this.lblroll);
            this.tabPage1.Controls.Add(this.lblwz);
            this.tabPage1.Controls.Add(this.lblwy);
            this.tabPage1.Controls.Add(this.lblwx);
            this.tabPage1.Controls.Add(this.lbltime);
            this.tabPage1.Controls.Add(this.tblpf);
            this.tabPage1.Controls.Add(this.cbbmhz);
            this.tabPage1.Controls.Add(this.cbbBaudRate);
            this.tabPage1.Controls.Add(this.cbbComList);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.lbllpf);
            this.tabPage1.Controls.Add(this.lblmhz);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btnSend);
            this.tabPage1.Controls.Add(this.btnOpen);
            this.tabPage1.Controls.Add(this.btnflashRead);
            this.tabPage1.Controls.Add(this.btnflashWrite);
            this.tabPage1.Controls.Add(this.btnSetParam);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1364, 593);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(73, 438);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 84;
            this.button2.Text = "清空";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // txtFile
            // 
            this.txtFile.Location = new System.Drawing.Point(907, 75);
            this.txtFile.Multiline = true;
            this.txtFile.Name = "txtFile";
            this.txtFile.Size = new System.Drawing.Size(184, 195);
            this.txtFile.TabIndex = 83;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(635, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 82;
            this.label3.Text = "校准结果：";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(79, 183);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 81;
            this.label9.Text = "16进制显示：";
            // 
            // cbbbaut
            // 
            this.cbbbaut.FormattingEnabled = true;
            this.cbbbaut.Items.AddRange(new object[] {
            "115200",
            "921600"});
            this.cbbbaut.Location = new System.Drawing.Point(637, 22);
            this.cbbbaut.Name = "cbbbaut";
            this.cbbbaut.Size = new System.Drawing.Size(100, 20);
            this.cbbbaut.TabIndex = 80;
            this.cbbbaut.Text = "115200";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(959, 330);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(132, 23);
            this.button1.TabIndex = 79;
            this.button1.Text = "MAG校准";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // lbltmp
            // 
            this.lbltmp.AutoSize = true;
            this.lbltmp.Location = new System.Drawing.Point(351, 264);
            this.lbltmp.Name = "lbltmp";
            this.lbltmp.Size = new System.Drawing.Size(137, 12);
            this.lbltmp.TabIndex = 78;
            this.lbltmp.Text = "时间时间是的的的的的的";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(627, 109);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(184, 195);
            this.textBox1.TabIndex = 77;
            // 
            // txtimuID
            // 
            this.txtimuID.Location = new System.Drawing.Point(167, 78);
            this.txtimuID.Name = "txtimuID";
            this.txtimuID.Size = new System.Drawing.Size(100, 21);
            this.txtimuID.TabIndex = 68;
            this.txtimuID.Text = "3";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(163, 475);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 65;
            // 
            // txtShowData
            // 
            this.txtShowData.Location = new System.Drawing.Point(79, 198);
            this.txtShowData.Multiline = true;
            this.txtShowData.Name = "txtShowData";
            this.txtShowData.Size = new System.Drawing.Size(223, 218);
            this.txtShowData.TabIndex = 59;
            // 
            // btncali
            // 
            this.btncali.Location = new System.Drawing.Point(637, 57);
            this.btncali.Name = "btncali";
            this.btncali.Size = new System.Drawing.Size(132, 23);
            this.btncali.TabIndex = 76;
            this.btncali.Text = "6D零偏校准";
            this.btncali.UseVisualStyleBackColor = true;
            this.btncali.Click += new System.EventHandler(this.btncali_Click_1);
            // 
            // lblyaw
            // 
            this.lblyaw.AutoSize = true;
            this.lblyaw.Location = new System.Drawing.Point(351, 142);
            this.lblyaw.Name = "lblyaw";
            this.lblyaw.Size = new System.Drawing.Size(137, 12);
            this.lblyaw.TabIndex = 75;
            this.lblyaw.Text = "时间时间是的的的的的的";
            // 
            // lblpitch
            // 
            this.lblpitch.AutoSize = true;
            this.lblpitch.Location = new System.Drawing.Point(351, 111);
            this.lblpitch.Name = "lblpitch";
            this.lblpitch.Size = new System.Drawing.Size(137, 12);
            this.lblpitch.TabIndex = 74;
            this.lblpitch.Text = "时间时间是的的的的的的";
            // 
            // lblroll
            // 
            this.lblroll.AutoSize = true;
            this.lblroll.Location = new System.Drawing.Point(351, 88);
            this.lblroll.Name = "lblroll";
            this.lblroll.Size = new System.Drawing.Size(137, 12);
            this.lblroll.TabIndex = 73;
            this.lblroll.Text = "时间时间是的的的的的的";
            // 
            // lblwz
            // 
            this.lblwz.AutoSize = true;
            this.lblwz.Location = new System.Drawing.Point(351, 230);
            this.lblwz.Name = "lblwz";
            this.lblwz.Size = new System.Drawing.Size(137, 12);
            this.lblwz.TabIndex = 72;
            this.lblwz.Text = "时间时间是的的的的的的";
            // 
            // lblwy
            // 
            this.lblwy.AutoSize = true;
            this.lblwy.Location = new System.Drawing.Point(351, 199);
            this.lblwy.Name = "lblwy";
            this.lblwy.Size = new System.Drawing.Size(137, 12);
            this.lblwy.TabIndex = 71;
            this.lblwy.Text = "时间时间是的的的的的的";
            // 
            // lblwx
            // 
            this.lblwx.AutoSize = true;
            this.lblwx.Location = new System.Drawing.Point(351, 176);
            this.lblwx.Name = "lblwx";
            this.lblwx.Size = new System.Drawing.Size(137, 12);
            this.lblwx.TabIndex = 70;
            this.lblwx.Text = "时间时间是的的的的的的";
            // 
            // lbltime
            // 
            this.lbltime.AutoSize = true;
            this.lbltime.Location = new System.Drawing.Point(496, 443);
            this.lbltime.Name = "lbltime";
            this.lbltime.Size = new System.Drawing.Size(137, 12);
            this.lbltime.TabIndex = 69;
            this.lbltime.Text = "时间时间是的的的的的的";
            // 
            // tblpf
            // 
            this.tblpf.Location = new System.Drawing.Point(157, 109);
            this.tblpf.Maximum = 100;
            this.tblpf.Name = "tblpf";
            this.tblpf.Size = new System.Drawing.Size(110, 45);
            this.tblpf.TabIndex = 67;
            // 
            // cbbmhz
            // 
            this.cbbmhz.FormattingEnabled = true;
            this.cbbmhz.Items.AddRange(new object[] {
            "100 ",
            "250 ",
            "500 ",
            "2 ",
            "0"});
            this.cbbmhz.Location = new System.Drawing.Point(167, 58);
            this.cbbmhz.Name = "cbbmhz";
            this.cbbmhz.Size = new System.Drawing.Size(100, 20);
            this.cbbmhz.TabIndex = 66;
            this.cbbmhz.Text = "100 ";
            // 
            // cbbBaudRate
            // 
            this.cbbBaudRate.FormattingEnabled = true;
            this.cbbBaudRate.Items.AddRange(new object[] {
            "115200",
            "921600"});
            this.cbbBaudRate.Location = new System.Drawing.Point(167, 38);
            this.cbbBaudRate.Name = "cbbBaudRate";
            this.cbbBaudRate.Size = new System.Drawing.Size(100, 20);
            this.cbbBaudRate.TabIndex = 64;
            this.cbbBaudRate.Text = "115200";
            // 
            // cbbComList
            // 
            this.cbbComList.FormattingEnabled = true;
            this.cbbComList.Items.AddRange(new object[] {
            "COM0",
            "COM1",
            "COM2",
            "COM3"});
            this.cbbComList.Location = new System.Drawing.Point(169, 18);
            this.cbbComList.Name = "cbbComList";
            this.cbbComList.Size = new System.Drawing.Size(98, 20);
            this.cbbComList.TabIndex = 63;
            this.cbbComList.Text = "COM0";
            this.cbbComList.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cbbComList_MouseClick_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(77, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 62;
            this.label2.Text = "IMUID";
            // 
            // lbllpf
            // 
            this.lbllpf.AutoSize = true;
            this.lbllpf.Location = new System.Drawing.Point(77, 123);
            this.lbllpf.Name = "lbllpf";
            this.lbllpf.Size = new System.Drawing.Size(53, 12);
            this.lbllpf.TabIndex = 61;
            this.lbllpf.Text = "低通参数";
            // 
            // lblmhz
            // 
            this.lblmhz.AutoSize = true;
            this.lblmhz.Location = new System.Drawing.Point(77, 66);
            this.lblmhz.Name = "lblmhz";
            this.lblmhz.Size = new System.Drawing.Size(71, 12);
            this.lblmhz.TabIndex = 60;
            this.lblmhz.Text = "发送频率 HZ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(79, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 58;
            this.label1.Text = "波特率";
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(73, 472);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 57;
            this.btnSend.Text = "发送";
            this.btnSend.UseVisualStyleBackColor = true;
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(79, 15);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 23);
            this.btnOpen.TabIndex = 56;
            this.btnOpen.Text = "打开端口";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click_1);
            // 
            // btnflashRead
            // 
            this.btnflashRead.Location = new System.Drawing.Point(638, 490);
            this.btnflashRead.Name = "btnflashRead";
            this.btnflashRead.Size = new System.Drawing.Size(75, 23);
            this.btnflashRead.TabIndex = 53;
            this.btnflashRead.Text = "读取闪存";
            this.btnflashRead.UseVisualStyleBackColor = true;
            this.btnflashRead.Click += new System.EventHandler(this.btnflashRead_Click_1);
            // 
            // btnflashWrite
            // 
            this.btnflashWrite.Location = new System.Drawing.Point(736, 490);
            this.btnflashWrite.Name = "btnflashWrite";
            this.btnflashWrite.Size = new System.Drawing.Size(75, 23);
            this.btnflashWrite.TabIndex = 54;
            this.btnflashWrite.Text = "写闪存";
            this.btnflashWrite.UseVisualStyleBackColor = true;
            this.btnflashWrite.Click += new System.EventHandler(this.btnflashWrite_Click_1);
            // 
            // btnSetParam
            // 
            this.btnSetParam.Location = new System.Drawing.Point(736, 319);
            this.btnSetParam.Name = "btnSetParam";
            this.btnSetParam.Size = new System.Drawing.Size(75, 23);
            this.btnSetParam.TabIndex = 55;
            this.btnSetParam.Text = "设置参数";
            this.btnSetParam.UseVisualStyleBackColor = true;
            this.btnSetParam.Click += new System.EventHandler(this.btnSetParam_Click_1);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1372, 619);
            this.tabControl1.TabIndex = 0;
            // 
            // ComDevice
            // 
            this.ComDevice.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.ComDevice_DataReceived);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1396, 643);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblpf)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txtFile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbbbaut;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbltmp;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox txtimuID;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox txtShowData;
        private System.Windows.Forms.Button btncali;
        private System.Windows.Forms.Label lblyaw;
        private System.Windows.Forms.Label lblpitch;
        private System.Windows.Forms.Label lblroll;
        private System.Windows.Forms.Label lblwz;
        private System.Windows.Forms.Label lblwy;
        private System.Windows.Forms.Label lblwx;
        private System.Windows.Forms.Label lbltime;
        private System.Windows.Forms.TrackBar tblpf;
        private System.Windows.Forms.ComboBox cbbmhz;
        private System.Windows.Forms.ComboBox cbbBaudRate;
        private System.Windows.Forms.ComboBox cbbComList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbllpf;
        private System.Windows.Forms.Label lblmhz;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnflashRead;
        private System.Windows.Forms.Button btnflashWrite;
        private System.Windows.Forms.Button btnSetParam;
        private System.Windows.Forms.TabControl tabControl1;
        private System.IO.Ports.SerialPort ComDevice;
        private System.Windows.Forms.Timer timer1;
    }
}

