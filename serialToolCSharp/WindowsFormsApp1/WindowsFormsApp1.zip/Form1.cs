﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Threading;
using System.Net;

using System.Collections;
using System.IO;
using System.Diagnostics;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        UInt32 baut = 921600;
        UInt16 mhz = 500;
        ReaderWriterLock _rwlock;// = new ReaderWriterLock();
        byte id = 2, uart_cnt, recv_i = 0xff, recv_frame_len;
        float walpha = 0;
   

        float raw_mag_x;
        float raw_mag_y;
        float raw_mag_z;

        float lraw_mag_x;
        float lraw_mag_y;
        float lraw_mag_z;
        string bufstring;
        StreamWriter sw;
        FileStream fs;
        float raw_w_x;
        float raw_w_y;
        float raw_w_z;

        float raw_acc_x;
        float raw_acc_y;
        float raw_acc_z;

        float EulerAngle_x;
        float EulerAngle_y;
        float EulerAngle_z;


        //mag_temp = qua[12];
        //acc_temp = qua[13];
        //arm_temp =qua[14];

        float yawmag;
        float yaww;
        float yawfilter;


        float cali_mag_x;
        float cali_mag_y;
        float cali_mag_z;


        float[] ofs, qua;
        byte[] uart_send_data;
        byte[] recv_buf, frame_buf;
        // Point[] pointList;
        int[] y;
        int[] z;
       
        Random r;

  

        DateTime startt;
        double timet;
        const int data_max_len = 1000;
        float[] froll = new float[data_max_len];
        float[] ftime = new float[data_max_len];
 
        bool calii, magcali;
        float wxofs, wyofs, wzofs, axofs, ayofs, azofs;

        private void ComDevice_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            byte[] ReDatas = new byte[ComDevice.BytesToRead];
            ComDevice.Read(ReDatas, 0, ReDatas.Length);//读取数据

            //foreach as in 
            foreach (byte a in ReDatas)
            {
                //state_machine(a);
                state_machine_18floats(a);
                //  this.txtShowData.Invoke(new Action(() =>
                //   {
                //    txtShowData.Text += a.ToString("X2") + ' ';

                // }));
            }
            Thread.Sleep(5);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (talk_status)
            {

                case 0x09://write flash ok

                    lbltime.Text = "写成功";
                    break;

                case 0x05://read flash ok

                    lbltime.Text = "读成功";

                    cbbbaut.Text = baut.ToString();

                    cbbmhz.Text = mhz.ToString();
                    tblpf.Value = (int)(walpha * 100);
                    txtimuID.Text = id.ToString();
                    lbllpf.Text = "低通参数" + (tblpf.Value / 100.0).ToString();

                    break;
                case 0x01://read flash ok

                    lbltime.Text = "设置参数成功";
                    break;
                    //default:
                    // lbltime.Text = "......";
                    //   break;
            }

            // lblroll.Text = "roll:" + roll.ToString();
            if (!clear)
            {
                if (bufstring.Length > 3000)
                    bufstring = bufstring.Substring(1000);
                txtShowData.Text = bufstring;

            }
            else
            {
                bufstring = "";
                clear = false;
            }


            // lbltime.Text = bufstring.Length.ToString();
            // lblpitch.Text = "pitch:" + pitch.ToString();
            lblroll.Text = "roll:" + EulerAngle_x.ToString();
            lblpitch.Text = "pitch:" + EulerAngle_y.ToString();
            lblyaw.Text = "yaw:" + EulerAngle_z.ToString();
            lblwx.Text = "rwx:" + raw_w_x.ToString();
            lblwy.Text = "rwy:" + raw_w_y.ToString();
            lblwz.Text = "rwz:" + raw_w_z.ToString();
            lbltmp.Text = "tempture:" + qua[17].ToString();
        }

        List<int> list = new List<int>();
        public Form1()
        {
            InitializeComponent();
            //  ComDevice =  new SerialPort();
            ofs = new float[6];
            qua = new float[26];
            calii = false;
            magcali = false;
            uart_send_data = new byte[100];
            _rwlock = new ReaderWriterLock();
            recv_buf = new byte[100];
            frame_buf = new byte[100];
            this.tabPage1.Text = "设置参数";

            //清空缓冲区

            fs = new FileStream("magdata.txt", FileMode.Create);
            sw = new StreamWriter(fs);

      
 
            bufstring = "";
            startt = DateTime.Now;// long timeStamp = (long)(DateTime.Now - startTime).TotalSeconds; // 相差毫秒数
            timet = (long)(DateTime.Now - startt).TotalMilliseconds;
            System.DateTime startTime = TimeZone.CurrentTimeZone.ToLocalTime(new System.DateTime(1970, 1, 1)); // 当地时区
            long timeStamp = (long)(DateTime.Now - startTime).TotalSeconds; // 相差毫秒数
 
            lbltime.Text = timeStamp.ToString();

 
            r = new Random();
            y = new int[9];
            z = new int[9];
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btncali_Click(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void cbbmhz_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cbbComList_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void btnSend_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnOpen_Click(object sender, EventArgs e)
        {

        }

        private void btnflashRead_Click(object sender, EventArgs e)
        {

        }

        private void btnflashWrite_Click(object sender, EventArgs e)
        {

        }

        private void btnSetParam_Click(object sender, EventArgs e)
        {

        }

        private void btnOpen_Click_1(object sender, EventArgs e)
        {
            if (ComDevice.IsOpen == false)
            {
                ComDevice.PortName = cbbComList.Text;// cbbComList.SelectedItem.ToString();
                ComDevice.BaudRate = Convert.ToInt32(cbbBaudRate.Text);

                ComDevice.Parity = Parity.None; //(Parity)Convert.ToInt32(cbbParity.SelectedIndex.ToString());
                ComDevice.DataBits = 8;//Convert.ToInt32(cbbDataBits.SelectedItem.ToString());
                ComDevice.StopBits = StopBits.One;// 1;//(StopBits)Convert.ToInt32(cbbStopBits.SelectedItem.ToString());
                try
                {
                    ComDevice.Open();
                    btnSend.Enabled = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                btnOpen.Text = "关闭串口";
                // pictureBox1.BackgroundImage = Properties.Resources.green;
            }
            else
            {
                try
                {
                    ComDevice.Close();
                    btnSend.Enabled = false;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                btnOpen.Text = "打开串口";
                //pictureBox1.BackgroundImage = Properties.Resources.red;
            }
        }

        private void btncali_Click_1(object sender, EventArgs e)
        {
            calii = !calii;

            if (calii)
                btncali.Text = "start calibrateion....";
            else
            {
                azofs -= 1;
                btncali.Text = "calibrateion over";
                textBox1.Text = "float wxofs =" + wxofs.ToString() +
                ";\r\nfloat wyofs =" + wyofs.ToString() +
                   ";\r\nfloat wzofs =" + wzofs.ToString() +
                    ";\r\nfloat Xofs =" + axofs.ToString() +
                    ";\r\nfloat Yofs =" + ayofs.ToString() +
                      ";\r\nfloat Zofs =" + azofs.ToString();




            }
        }

        private void btnSetParam_Click_1(object sender, EventArgs e)
        {
            lbltime.Text = "设置中...";
            // cbbBaudRate
            baut = Convert.ToUInt32(cbbbaut.Text);
            mhz = Convert.ToUInt16(cbbmhz.Text);
            walpha = (float)(tblpf.Value / 100.0);
            id = Convert.ToByte(txtimuID.Text);
            ofs[0] = wxofs;// (float)Convert.ToSingle(tbwxofs.Text); //wxofs
            ofs[1] = wyofs;// (float)Convert.ToSingle(tbwyofs.Text); ;
            ofs[2] = wzofs;// (float)Convert.ToSingle(tbwzofs.Text); ;// wzofs
            ofs[3] = axofs;// (float)Convert.ToSingle(tbaxofs.Text); ;//axofs
            ofs[4] = ayofs;// (float)Convert.ToSingle(tbayofs.Text); ;
            ofs[5] = azofs;// (float)Convert.ToSingle(tbazofs.Text); ;
            vars2bytesAndSend((byte)0);
        }
        UInt16 CRC16Encode(byte[] buf, byte len)
        {
            UInt16 crc_gen = 0xa001;
            UInt16 crc;
            byte i, j;
            crc = 0xffff;
            if (len != 0)
            {
                for (i = 0; i < len; i++)
                {
                    crc ^= (UInt16)(buf[i]);
                    for (j = 0; j < 8; j++)
                    {
                        if ((crc & 0x01) == 0x01) { crc >>= 1; crc ^= crc_gen; }
                        else crc >>= 1;
                    }
                }
            }
            return crc;
        }

  
        private void cbbComList_MouseClick_1(object sender, MouseEventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            cbbComList.DataSource = ports;
        }

        byte N1_CalCheckSum(byte[] buf, byte iLen)
        {
            byte byteCheckSum = 0;
            UInt16 UInt16Index = 0;

            // if((byte)0 == iData) return 0;

            for (; UInt16Index < iLen; UInt16Index++)
            {
                byteCheckSum += buf[UInt16Index];
            }

            return byteCheckSum;
        }


        byte deal_a_frame(byte[] buf, byte len)
        {
            UInt16 crc = CRC16Encode(buf, (byte)(len - 3));
            byte crcL = (byte)crc;
            byte crcH = (byte)(crc >> 8);
            //printf("%x,l%x,h,%x,buf%x,buf%x\n",crc,crcL,crcH,buf[len-3],buf[len-2]);
            if (crcL == buf[len - 3] && crcH == buf[len - 2])
            {
                // printf("%x,l%x,h,%x\n",crc,crcL,crcH);
            }
            else
            {
                // ROS_ERROR("crc error\n");
                return 0;
            }

            byte check = N1_CalCheckSum(buf, (byte)(len - 1));

            if (check == buf[len - 1])
            { }
            else
            {
                //printf("%x,l%x,h,%x\n",crc,crcL,crcH);
                // ROS_ERROR("checksum error\n");
                return 0;

            }

            if (buf[0] == 0xa5 && buf[1] == 0x5a)
            {

                Buffer.BlockCopy(buf, 4, qua, 0, 4 * 18);

                lraw_mag_x = raw_mag_x;
                lraw_mag_y = raw_mag_y;
                lraw_mag_z = raw_mag_z;


                raw_mag_x = qua[0];
                raw_mag_y = qua[1];
                raw_mag_z = qua[2];

                raw_w_x = qua[3];
                raw_w_y = qua[4];
                raw_w_z = qua[5];

                raw_acc_x = qua[6];
                raw_acc_y = qua[7];
                raw_acc_z = qua[8];
                if (magcali)
                {
                    if (System.Math.Abs(raw_mag_x - lraw_mag_x) > 3 || System.Math.Abs(raw_mag_y - lraw_mag_y) > 3 || System.Math.Abs(raw_mag_z - lraw_mag_z) > 3)
                        sw.Write(raw_mag_x.ToString() + "\t" + raw_mag_y.ToString() + "\t" + raw_mag_z.ToString() + "\r\n");
                }

                if (calii)
                {

                    wxofs += raw_w_x;
                    wyofs += raw_w_y;
                    wzofs += raw_w_z;

                    axofs += raw_acc_x;
                    ayofs += raw_acc_y;
                    azofs += raw_acc_z;

                    wxofs /= 2.0f;
                    wyofs /= 2.0f;
                    wzofs /= 2.0f;

                    axofs /= 2.0f;
                    ayofs /= 2.0f;
                    azofs /= 2.0f;
                }

                EulerAngle_x = qua[9];
                EulerAngle_y = qua[10];
                EulerAngle_z = qua[11];

                //mag_temp = qua[12];
                //acc_temp = qua[13];
                //arm_temp =qua[14];

                yawmag = qua[12];
                yaww = qua[13];
                yawfilter = qua[14];

                cali_mag_x = qua[15];
                cali_mag_y = qua[16];
                cali_mag_z = qua[17];
            }
            return 1; //true
        }
        void state_machine_18floats(byte c)
        {
            bufstring = bufstring + " " + Convert.ToString(c, 16);
            switch (recv_i)
            {
                case 0xff:
                    if (c == 0xa5)
                    {
                        recv_i = 0;
                        recv_buf[recv_i] = c;
                        //printf("case 1\n");
                    }
                    break;
                case 0:
                    if (c == 0x5a)
                    {
                        recv_i = 1;
                        recv_buf[recv_i] = c;
                        //printf("case 2\n");
                    }
                    break;
                case 1:
                    //printf("case 3\n");
                    recv_frame_len = (c);
                    //printf("recv_frame_len %d\n",recv_frame_len);
                    if (recv_frame_len > 90)
                    {
                        recv_i = 0xff;
                        //print_buf();
                        // printf("if: --error --recv_frame_len%x, %d\n",recv_buff[3],recv_frame_len);
                        break;
                    }
                    //else printf("else: recv_frame_len%x, %d\n",recv_buff[3],recv_frame_len);
                    //printf("recv_frame_len %d\n",recv_frame_len);
                    recv_i = 2;
                    recv_buf[recv_i] = c;
                    break;
                default:
                    //printf("case 4 %d\n",recv_i);
                    recv_i++;
                    if (recv_i > 2 && recv_i < recv_frame_len)
                        recv_buf[recv_i] = c;
                    if (recv_i + 1 == recv_frame_len)
                    {

                        //for(int i = 0;i<recv_frame_len;i++)
                        //    printf("%2x ",recv_buff[i]);
                        //printf("--\n ");

                        if (recv_frame_len == 40)
                        {
                            Console.Write("recv_frame_len%d--\n ", recv_frame_len);
                            flash_data_frame(recv_buf, recv_frame_len);
                        }
                        else
                        {
                            deal_a_frame(recv_buf, recv_frame_len);
                        }
                        //printf("--%x\n ",recv_buff[3]);
                        recv_i = 0xff;
                    }
                    //else recv_i = 0xff;
                    break;
            }
            //return 0;
        }
/*
        void state_machine(byte c)
        {
            bufstring = bufstring + " " + Convert.ToString(c, 16);
            switch (recv_i)
            {
                case 0xff:
                    if (c == 0xa5)
                    {
                        recv_i = 0;
                        recv_buf[recv_i] = c;
                        //ROS_INFO("case 1\n");
                    }
                    break;
                case 0:
                    if (c == 0x5a)
                    {
                        recv_i = 1;
                        recv_buf[recv_i] = c;
                        //ROS_INFO("case 2\n");
                    }
                    break;
                case 1:
                    // ROS_INFO("case 3\n");
                    recv_frame_len = (byte)((c) + 4);
                    if (recv_frame_len == 44) recv_frame_len -= 4;
                    // ROS_INFO("recv_frame_len %d\n",recv_frame_len);
                    if (!(recv_frame_len == 24 || recv_frame_len == 40))
                    // if( recv_frame_len!=24 ) 
                    {
                        recv_i = 0xff;
                        //print_buf();
                        // ROS_INFO("if: --error --recv_frame_len%x, %d\n",recv_buff[3],recv_frame_len);
                        break;
                    }
                    //else ROS_INFO("else: recv_frame_len%x, %d\n",recv_buff[3],recv_frame_len);
                    //ROS_INFO("recv_frame_len %d\n",recv_frame_len);
                    recv_i = 2;
                    recv_buf[recv_i] = c;
                    break;
                default:
                    //ROS_INFO("case 4 %d\n",recv_i);
                    recv_i++;
                    if (recv_i > 2 && recv_i < recv_frame_len)
                        recv_buf[recv_i] = c;
                    if (recv_i + 1 == recv_frame_len)
                    {
                        if (recv_frame_len == 40)
                        {
                            Console.Write("recv_frame_len%d--\n ", recv_frame_len);
                            flash_data_frame(recv_buf, recv_frame_len);
                        }

                        else
                        {
                            N1_RawDataRx1(recv_buf, recv_frame_len);
                            //deal_a_frame(recv_buff, recv_frame_len);
                        }
                        recv_i = 0xff;

                    }

                    break;
            }
            //return 0;
        }
*/
        byte talk_status = 0;
        byte flash_data_frame(byte[] frame_buf, byte len)
        {
            UInt16 crc = CRC16Encode(frame_buf, (byte)(len - 3));
            byte crcL = (byte)crc;
            byte crcH = (byte)(crc >> 8);
            //printf("%x,l%x,h,%x,buf%x,buf%x\n",crc,crcL,crcH,buf[len-3],buf[len-2]);
            if (crcL == frame_buf[len - 3] && crcH == frame_buf[len - 2])
            {
                // printf("%x,l%x,h,%x\n",crc,crcL,crcH);
            }
            else
            {
                // ROS_ERROR("crc error\n");
                return 0;
            }

            byte check = N1_CalCheckSum(frame_buf, (byte)(len - 1));
            //printf("%x,l%x\n",check,buf[len-1]);
            if (check == frame_buf[len - 1])
            { }
            else
            {
                //printf("%x,l%x,h,%x\n",crc,crcL,crcH);
                // ROS_ERROR("checksum error\n");
                return 0;

            }

            if (frame_buf[0] == 0xa5 && frame_buf[1] == 0x5a)
            {
                talk_status = frame_buf[4];



                Buffer.BlockCopy(frame_buf, 5, ofs, 0, 24);

                //ofs[0] = BitConverter.ToSingle(frame_buf, 5);
                //ofs[1] = BitConverter.ToSingle(frame_buf, 9);
                //ofs[2] = BitConverter.ToSingle(frame_buf, 13);
                //ofs[3] = BitConverter.ToSingle(frame_buf, 17);
                //ofs[4] = BitConverter.ToSingle(frame_buf, 21);
                //ofs[5] = BitConverter.ToSingle(frame_buf, 25);

                baut = BitConverter.ToUInt32(frame_buf, 29);
                // memcpy(&baut, &frame_buf[29], 4);
                mhz = BitConverter.ToUInt16(frame_buf, 33);
                //txtimuID.Text = "325";// 230.ToString();// mhz.ToString();
                // memcpy(&mhz, &frame_buf[33], 2);

                walpha = (float)(frame_buf[35] / 255.0);
                id = frame_buf[36];
                /*
                Console.Out.Write("baut,hz,id,walpha=[%d,%d,%d,%f \n", baut, mhz, id, walpha);

                this.txtShowData.Invoke(new Action(() =>
                {
                    cbbbaut.Text = baut.ToString();
                  
                    cbbmhz.Text = mhz.ToString();
                    tblpf.Value = (int)(walpha * 100);
                    txtimuID.Text = id.ToString();
                    lbllpf.Text = "低通参数" + (tblpf.Value / 100.0).ToString();
           
                }));*/

            }

            return 1;

        }


        byte vars2bytesAndSend(byte wr)
        {
            try
            {
                uart_send_data[0] = 0xa5;
                uart_send_data[1] = 0x5a;
                uart_send_data[2] = 40;//len
                uart_send_data[3] = uart_cnt++;
                uart_send_data[4] = wr;

                Buffer.BlockCopy(ofs, 0, uart_send_data, 5, 24);

                UInt32[] ff = { baut };
                Buffer.BlockCopy(ff, 0, uart_send_data, 29, 4);

                //Buffer.BlockCopy(ofs, 0, uart_send_data, 5, 24);
                uart_send_data[33] = (byte)(mhz & 0xff);
                uart_send_data[34] = (byte)(mhz >> 8);
                uart_send_data[35] = (byte)(walpha * 255);
                uart_send_data[36] = id;

                UInt16 crc = CRC16Encode(uart_send_data, 37);
                uart_send_data[37] = (byte)(crc & 0x00ff);
                uart_send_data[38] = (byte)((crc & 0xff00) >> 8);
                uart_send_data[39] = N1_CalCheckSum(uart_send_data, 39);

                flash_data_frame(uart_send_data, 40);
                ComDevice.Write(uart_send_data, 0, 40);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }

            return 1;

        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            magcali = !magcali;

            if (magcali)
            {
                button1.Text = "mag dataing ...";

                //开始写入
                //sw.Write("Hello World!!!!");
            }
            else
            {
                button1.Text = "mag 参数";
                try
                {
                    sw.Flush();
                    //关闭流
                    sw.Close();
                    fs.Close();

                    Process p;
                    p = new System.Diagnostics.Process();

                    p.StartInfo.FileName = "MagCal.exe";
                    p.Start();
                    Thread.Sleep(1000);
                    bool b = p.HasExited;
                    p.WaitForExit();
                    b = p.HasExited;
                    p.Close();

                    StreamReader sr = new StreamReader("magparam.txt", Encoding.Default);
                    String line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        Console.WriteLine(line.ToString());
                        txtFile.Text += line.ToString() + "\r\n";
                    }

                }
                catch (Exception ex)
                {

                }


            }
        }

        private void btnflashRead_Click_1(object sender, EventArgs e)
        {
            vars2bytesAndSend((byte)4);
            lbltime.Text = "读取中....";
            txtimuID.Text = qua[16].ToString();
        }

        private void btnflashWrite_Click_1(object sender, EventArgs e)
        {
            vars2bytesAndSend((byte)8);
            lbltime.Text = "写中....";
        }
        bool clear;
        private void button2_Click_1(object sender, EventArgs e)
        {
            clear = true;
        }
    }
}
